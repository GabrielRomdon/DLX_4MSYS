vcom ../000-globals.vhd
vcom ../a.a-CU_HW.vhd
vcom TB_CU.vhd
