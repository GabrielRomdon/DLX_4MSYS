Folder that contains the files relevant for alu testing.

For compiling, use the following commands:
vcom -mixedsvvh -f compile_vhdl.f
vlog -mixedsvvh -f compile.f

